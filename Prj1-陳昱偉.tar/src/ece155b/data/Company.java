package ece155b.data;

public class Company
{
	public String name;
	public String address;
	public String contact;
}