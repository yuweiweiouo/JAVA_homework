package ece155b.data;

public class Supply
{
	public String name;
	public double price;

}