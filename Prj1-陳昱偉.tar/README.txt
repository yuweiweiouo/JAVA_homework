# JAVA_homework
Open cmd and do the script

$ant compile  
-compile the program
 
$ant run
-compile and run the program 

==================================

xml file for testing is under the SavedXml folder


